import React from 'react';

export default function App() {
  return (
    <div style={{ fontFamily: 'sans-serif', padding: 20 }}>
      <img src="/cobaem/log.jpeg" alt="Logo COBAEM" style={{ height: 80 }} />
      <h1>Portal COBAEM Contepec</h1>
      <p>Bienvenido al portal escolar.</p>
    </div>
  );
}
