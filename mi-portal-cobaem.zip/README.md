# Portal COBAEM Contepec

Proyecto en React + Vite con conexión a Supabase.

## Instalación
```bash
npm install
npm run dev
```

## Build para producción
```bash
npm run build
```

Sube el contenido a tu repositorio `intento6` y despliega en Vercel.
